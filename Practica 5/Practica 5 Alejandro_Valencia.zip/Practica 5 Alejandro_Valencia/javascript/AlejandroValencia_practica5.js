window.onload = function() {
    // Animacion para el mensaje de instrucciones
    setTimeout(function() {
        document.getElementById('instrucciones').style.bottom = '50px';
    }, 500);  // Retrasa la animacion 500ms despues de cargar la pagina

    document.getElementById('iniciarJuego').addEventListener('click', function() {
        // Ocultamos la pantalla de inicio
        document.getElementById('inicio').style.display = 'none';
        
        // Mostramos la pantalla principal del juego
        document.getElementById('juego').style.display = 'block';
    });
};
