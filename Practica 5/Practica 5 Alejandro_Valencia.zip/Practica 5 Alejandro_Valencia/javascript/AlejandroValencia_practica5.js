window.onload = () => {
    //aprovechando lo que hemos visto hoy en clase 
    class ContadorRegresivo extends HTMLElement {
        connectedCallback() {
            this.innerHTML = `<div id="contador" class="contador"></div>`;
        }

        set valor(val) {
            this.querySelector('#contador').textContent = val;
        }
    }
    customElements.define('contador-regresivo', ContadorRegresivo);
//las constantes usadas para el juego 
    const instrucciones = document.getElementById('instrucciones');
    const inicio = document.getElementById('inicio');
    const juego = document.getElementById('juego');
    const jugador = document.getElementById('jugador');
    const objetivo = document.getElementById('objetivo');
    const finalDiv = document.getElementById('final');
    let posX = window.innerWidth / 2 - 25;
    let posY = window.innerHeight / 2 - 25;
    let juegoTerminado = false;
    let objetivoY = 50;

    // Mostrar/ocultar instrucciones
    document.getElementById('toggleInstrucciones').addEventListener('click', () => {
        instrucciones.classList.toggle('mostrar');
    });

    // Iniciar juego con contador regresivo
    document.getElementById('iniciarJuego').addEventListener('click', async () => {
        await cuentaRegresiva();
        iniciarJuego();
    });

    async function cuentaRegresiva() {
        const contadorComp = document.createElement('contador-regresivo');
        document.body.appendChild(contadorComp);
        for (let i = 3; i >= 0; i--) {
            contadorComp.valor = i;
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
        contadorComp.remove();
    }

    function iniciarJuego() {
        inicio.style.display = 'none';
        juego.style.display = 'block';
        setTimeout(finalizarJuego, 10000); // El juego dura 10 segundos
        moverJugador();
        animarObjetivo();
    }
//movimiento del jugador 
    function moverJugador() {
        document.addEventListener('keydown', (event) => {
            if (juego.style.display === 'block') {
                const movimientos = {
                    ArrowUp: [0, -10],
                    ArrowDown: [0, 10],
                    ArrowLeft: [-10, 0],
                    ArrowRight: [10, 0]
                };
                const [dx, dy] = movimientos[event.key] || [0, 0];
                posX = Math.max(0, Math.min(window.innerWidth - 50, posX + dx));
                posY = Math.max(0, Math.min(window.innerHeight - 50, posY + dy));
                jugador.style.transform = `translate(${posX}px, ${posY}px)`;
                verificarColision();
            }
        });
    }

    function verificarColision() {
        const jugadorRect = jugador.getBoundingClientRect();
        const objetivoRect = objetivo.getBoundingClientRect();
        if (
            jugadorRect.left < objetivoRect.right &&
            jugadorRect.right > objetivoRect.left &&
            jugadorRect.top < objetivoRect.bottom &&
            jugadorRect.bottom > objetivoRect.top
        ) {
            juegoTerminado = true;
            mostrarResultado("¡Has ganado!", "Llegaste al objetivo a tiempo.");
        }
    }

    function finalizarJuego() {
        if (!juegoTerminado) {
            mostrarResultado("Juego terminado", "No lograste llegar al objetivo a tiempo.");
        }
    }

    function mostrarResultado(titulo, mensaje) {
        juego.style.display = 'none';
        finalDiv.innerHTML = `
            <h2>${titulo}</h2>
            <p>${mensaje}</p>
            <button id="reiniciarJuego">Reiniciar Juego</button>
        `;
        finalDiv.style.display = 'block';
        document.getElementById('reiniciarJuego').addEventListener('click', reiniciarJuego);
    }

    function reiniciarJuego() {
        finalDiv.style.display = 'none';
        inicio.style.display = 'block';
        posX = window.innerWidth / 2 - 25;
        posY = window.innerHeight / 2 - 25;
        jugador.style.transform = `translate(${posX}px, ${posY}px)`;
        juegoTerminado = false;
    }


    //el  cuadrado a tocar se mueve 
    function animarObjetivo() {
        function mover() {
            if (!juegoTerminado) {
                objetivoY += Math.sin(Date.now() / 200) * 2;
                objetivo.style.transform = `translateY(${objetivoY}px)`;
                requestAnimationFrame(mover);
            }
        }
        mover();
    }
};
