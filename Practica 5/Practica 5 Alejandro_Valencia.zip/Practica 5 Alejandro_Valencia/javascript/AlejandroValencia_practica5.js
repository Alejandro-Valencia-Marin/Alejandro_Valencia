window.onload = function() {
    
    setTimeout(function() {
        document.getElementById('instrucciones').style.bottom = '50px';
    }, 500);

    document.getElementById('iniciarJuego').addEventListener('click', function() {
        mostrarContador();
    });

    function mostrarContador() {
        let contador = 3;
        const contadorDiv = document.createElement('div');
        contadorDiv.id = 'contador';
        contadorDiv.style.position = 'absolute';
        contadorDiv.style.top = '50%';
        contadorDiv.style.left = '50%';
        contadorDiv.style.transform = 'translate(-50%, -50%)';
        contadorDiv.style.fontSize = '48px';
        contadorDiv.style.fontWeight = 'bold';
        contadorDiv.style.color = '#333';
        document.body.appendChild(contadorDiv);

        const interval = setInterval(function() {
            contadorDiv.textContent = contador;
            contador--;

            if (contador < 0) {
                clearInterval(interval);
                contadorDiv.remove();
                iniciarJuego();
            }
        }, 1000);
    }

    function iniciarJuego() {
        document.getElementById('inicio').style.display = 'none';
        document.getElementById('juego').style.display = 'block';
    }

    class ScoreCard extends HTMLElement {
        connectedCallback() {
            this.innerHTML = `
                <div style="border: 1px solid black; padding: 10px; margin-top: 10px;">
                    <h3>Jugador: ${this.getAttribute('jugador') || 'Jugador'}</h3>
                    <p>Puntuación: ${this.getAttribute('puntuacion') || '0'}</p>
                </div>
            `;
        }
    }

    customElements.define('score-card', ScoreCard);

    // Movimiento del jugador
    let jugador = document.getElementById('jugador');
    let posX = window.innerWidth / 2 - 25;
    let posY = window.innerHeight / 2 - 25;

    document.addEventListener('keydown', function(event) {
        switch(event.key) {
            case 'ArrowUp': posY -= 10; break;
            case 'ArrowDown': posY += 10; break;
            case 'ArrowLeft': posX -= 10; break;
            case 'ArrowRight': posX += 10; break;
        }
        jugador.style.transform = `translate(${posX}px, ${posY}px)`;
    });
};

