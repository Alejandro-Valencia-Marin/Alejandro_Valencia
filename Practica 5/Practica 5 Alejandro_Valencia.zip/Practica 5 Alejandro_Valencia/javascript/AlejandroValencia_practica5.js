window.onload = () => {
    const instrucciones = document.getElementById('instrucciones');
    const inicio = document.getElementById('inicio');
    const juego = document.getElementById('juego');
    const jugador = document.getElementById('jugador');
    const finalDiv = document.getElementById('final');
    let posX = window.innerWidth / 2 - 25;
    let posY = window.innerHeight / 2 - 25;

    setTimeout(function() {
        document.getElementById('instrucciones').style.bottom = '50px';
    }, 500);

    document.getElementById('iniciarJuego').addEventListener('click', function() {
        mostrarContador();
    });
    
    document.getElementById('iniciarJuego').addEventListener('click', () => {
        let contador = 3;
        const contadorDiv = crearContador();
        const interval = setInterval(() => {
            contadorDiv.textContent = contador--;
            if (contador < 0) {
                clearInterval(interval);
                contadorDiv.remove();
                iniciarJuego();
            }
        }, 1000);
    });

    function iniciarJuego() {
        inicio.style.display = 'none';
        juego.style.display = 'block';
        setTimeout(finalizarJuego, 10000);
    }

    function finalizarJuego() {
        juego.style.display = 'none';
        finalDiv.innerHTML = `
            <h2>¡Juego terminado!</h2>
            <p>Gracias por jugar. ¿Quieres intentarlo de nuevo?</p>
            <button id="reiniciarJuego">Reiniciar Juego</button>
        `;
        finalDiv.style.display = 'block';
        document.getElementById('reiniciarJuego').addEventListener('click', () => {
            finalDiv.style.display = 'none';
            inicio.style.display = 'block';
        });
    }

    document.addEventListener('keydown', (event) => {
        const movimientos = {
            ArrowUp: [0, -10],
            ArrowDown: [0, 10],
            ArrowLeft: [-10, 0],
            ArrowRight: [10, 0]
        };
        const [dx, dy] = movimientos[event.key] || [0, 0];
        posX += dx;
        posY += dy;
        jugador.style.transform = `translate(${posX}px, ${posY}px)`;
    });

    class ScoreCard extends HTMLElement {
        connectedCallback() {
            this.innerHTML = `
                <div class="score-card">
                    <h3>Jugador: ${this.getAttribute('jugador') || 'Jugador'}</h3>
                    <p>Puntuación: ${this.getAttribute('puntuacion') || '0'}</p>
                </div>
            `;
        }
    }

    customElements.define('score-card', ScoreCard);

    function crearContador() {
        const div = document.createElement('div');
        div.id = 'contador';
        div.classList.add('contador');
        document.body.appendChild(div);
        return div;
    }
};
