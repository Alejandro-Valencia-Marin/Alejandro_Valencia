window.onload = function() {
    // Animacion para el mensaje de instrucciones
    setTimeout(function() {
        document.getElementById('instrucciones').style.bottom = '50px';
    }, 500);

    document.getElementById('iniciarJuego').addEventListener('click', function() {
        // Ocultamos la pantalla de inicio
        document.getElementById('inicio').style.display = 'none';
        
        // Mostramos la pantalla principal del juego
        document.getElementById('juego').style.display = 'block';
    });

    // Variables de posicion del jugador
    let jugador = document.getElementById('jugador');
    let posX = window.innerWidth / 2 - 25;  
    let posY = window.innerHeight / 2 - 25; 

    function moverJugador() {
        jugador.style.transform = `translate(${posX}px, ${posY}px)`;
        requestAnimationFrame(moverJugador);  // Repite el movimiento
    }

    // Controlar el movimiento con las teclas de flecha
    document.addEventListener('keydown', function(event) {
        switch(event.key) {
            case 'ArrowUp':
                posY -= 10;
                break;
            case 'ArrowDown':
                posY += 10;
                break;
            case 'ArrowLeft':
                posX -= 10;
                break;
            case 'ArrowRight':
                posX += 10;
                break;
        }
    });

    moverJugador(); // Iniciar el movimiento
};
