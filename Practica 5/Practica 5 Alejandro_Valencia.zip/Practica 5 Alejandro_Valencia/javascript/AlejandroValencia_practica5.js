document.getElementById('iniciarJuego').addEventListener('click', function() {
    // Ocultamos la pantalla de inicio
    document.getElementById('inicio').style.display = 'none';
    
    // Mostramos la pantalla principal del juego
    document.getElementById('juego').style.display = 'block';
});
